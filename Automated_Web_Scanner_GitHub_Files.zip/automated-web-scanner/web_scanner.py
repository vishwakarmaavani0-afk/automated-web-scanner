"""
Automated Web Scanner - HTTP Security Headers and CORS Audit
Author: Avani Vishwakarma | BCA | SMS Lucknow

Educational, low-volume checker. Scan only websites you own or have permission to assess.
"""
from urllib.parse import urlparse
import requests

SECURITY_HEADERS = {
    "Strict-Transport-Security": "Encourages browsers to use HTTPS.",
    "Content-Security-Policy": "Helps restrict sources of page content and scripts.",
    "X-Frame-Options": "Helps reduce clickjacking risk.",
    "X-Content-Type-Options": "Helps prevent MIME-sniffing.",
    "Referrer-Policy": "Controls referrer information sent by browsers.",
}
TIMEOUT_SECONDS = 10
REPORT_FILE = "scan_report.txt"

def normalize_url(target):
    target = target.strip()
    if not target:
        raise ValueError("Please enter a website domain or URL.")
    if "://" not in target:
        target = "https://" + target
    parsed = urlparse(target)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("Enter a valid http:// or https:// URL.")
    return target

def scan_website(target):
    url = normalize_url(target)
    findings = [
        "AUTOMATED WEB SCANNER (HTTP Security Headers & CORS)",
        f"Target: {url}",
        "-" * 60,
        "1. HTTP SECURITY HEADERS ANALYSIS",
    ]
    try:
        response = requests.get(
            url, timeout=TIMEOUT_SECONDS, allow_redirects=True,
            headers={"User-Agent": "AutomatedWebScanner/1.0 (educational audit)"}
        )
        findings.extend([f"HTTP status: {response.status_code}", f"Final URL: {response.url}"])
        for header, purpose in SECURITY_HEADERS.items():
            value = response.headers.get(header)
            if value:
                findings.append(f"[+] {header}: Present ({value})")
            else:
                findings.append(f"[-] MISSING: {header} -> {purpose}")
        findings.append("2. CORS CHECK")
        cors_value = response.headers.get("Access-Control-Allow-Origin")
        if cors_value:
            findings.append(f"[i] Access-Control-Allow-Origin: {cors_value}")
            if cors_value.strip() == "*":
                findings.append("[!] Wildcard origin found. Review whether public cross-origin access is intended.")
        else:
            findings.append("[i] Access-Control-Allow-Origin header not found (this can be normal).")
        findings.extend(["", "Note: This is a basic header check, not a complete security assessment."])
    except requests.exceptions.Timeout:
        findings.append(f"[!] Connection timed out after {TIMEOUT_SECONDS} seconds.")
    except requests.exceptions.SSLError:
        findings.append("[!] TLS/SSL error: the secure connection could not be verified.")
    except requests.exceptions.RequestException as exc:
        findings.append(f"[!] Connection error: {exc}")
    return findings

def main():
    try:
        target = input("Enter target website URL (e.g., example.com): ")
        results = scan_website(target)
        print("\\n" + "=" * 60)
        for line in results:
            print(line)
        print("=" * 60)
        with open(REPORT_FILE, "w", encoding="utf-8") as report:
            report.write("\\n".join(results) + "\\n")
        print(f"\\n[+] Scan finished. Report saved to '{REPORT_FILE}'.")
    except ValueError as exc:
        print(f"[!] Input error: {exc}")

if __name__ == "__main__":
    main()
