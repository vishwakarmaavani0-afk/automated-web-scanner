# Automated Web Scanner (HTTP Security Headers & CORS)

**Author:** Avani Vishwakarma  
**Course:** BCA  
**Institution:** SMS Lucknow

## Overview
A beginner-friendly Python program that sends one HTTP GET request to a website and checks five common HTTP security headers and the `Access-Control-Allow-Origin` CORS response header. Findings are printed and saved to `scan_report.txt`.

## Features
- Adds `https://` if a scheme is not provided.
- Checks HSTS, CSP, X-Frame-Options, X-Content-Type-Options, and Referrer-Policy.
- Reports the CORS response header and flags `*` for review.
- Handles timeout, TLS, and other request errors.
- Saves findings to a text report.

## Requirements
- Python 3.9 or newer
- Internet connection
- `requests` Python package

## Run the project
1. Install Python from https://www.python.org/downloads/ if needed.
2. Open Terminal / Command Prompt in this folder.
3. Install the dependency:
   ```bash
   python -m pip install -r requirements.txt
   ```
4. Run:
   ```bash
   python web_scanner.py
   ```
5. Enter a domain such as `example.com` or a full URL such as `https://example.com`.
6. Open `scan_report.txt` to view the saved results.

## Project files
- `web_scanner.py` — Python source code
- `requirements.txt` — dependency list
- `Project_Report.pdf` — project report
- `README.md` — project instructions
- `.gitignore` — excludes generated report and cache files

## Limitations
This is an educational header checker, not a full penetration-testing tool. A missing header does not automatically prove an exploitable vulnerability, and wildcard CORS needs context. The tool checks response headers only; it does not crawl pages or test application logic.

## Responsible use
Only scan websites you own or have explicit permission to assess. Keep requests low-volume and follow the site's terms and policies.
